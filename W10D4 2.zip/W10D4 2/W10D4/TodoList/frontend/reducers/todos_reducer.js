import { RECEIVE_TODO, RECEIVE_TODOS } from '../actions/todo_actions'

const initialState = {
  1: {
    id: 1,
    title: "wash car",
    body: "with soap",
    done: false
  },
  2: {
    id: 2,
    title: "wash dog",
    body: "with shampoo",
    done: true
  }
};



const todosReducer = (state = {}, action) => {
  Object.freeze(state)
  //debugger;
	switch (action.type) {
    case RECEIVE_TODOS:
      let newState = {};
      console.log(action.todos)
      action.todos.forEach(todo => {
      newState[todo.id] = todo;
      });
      return newState;
		case RECEIVE_TODO:
    //debugger;
    let newAdd = {[action.todo.id]: action.todo};
      return Object.assign({}, state, newAdd);
		default:
			return state;
	};

}




export default todosReducer;