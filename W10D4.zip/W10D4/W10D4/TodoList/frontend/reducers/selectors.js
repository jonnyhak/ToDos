


export const allTodos = ({ todos }) => {
  debugger
  return Object.keys(todos).map(key => todos[key]);

}




export default allTodos;