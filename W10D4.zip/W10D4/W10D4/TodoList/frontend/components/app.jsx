import React from 'react';





const App = ({ store }) => {
  return (

    <h1>This is a test if App works</h1>

  );

};


export default App;