import { receiveTodo, receiveTodos } from './frontend/actions/todo_actions'
import { allTodos } from './frontend/reducers/selectors'

import React from 'react';
import ReactDOM from 'react-dom';
import configureStore from './frontend/store/store'; //Was calling store instead of configureStore

import Root from './frontend/components/root'


document.addEventListener("DOMContentLoaded", () => {
const Element = () => <h1>Hello, world</h1>;
  const root = document.getElementById('root');
  window.store = configureStore;
  window.receiveTodo = receiveTodo;
  window.receiveTodos = receiveTodos;
  window.allTodos = allTodos;
  console.log("Hit Line 9");
  ReactDOM.render(<Root store={store} />, root); //Had to put Root store={store}
});




